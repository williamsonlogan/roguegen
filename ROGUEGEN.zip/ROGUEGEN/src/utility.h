#ifndef _UTILITY_H__
#define _UTILITY_H__

#include <stdlib.h>

typedef struct Coord
{
	int x;
	int y;
} Coord;

int intRand(int min, int max);

#endif // _UTILITY_H__
