#include "dungeon.h"

Room ** buildDungeon()
{
	//TODO: make dungeon size compatable with something other than 9
	Room ** dungeon;
	dungeon = malloc(sizeof(Room*)*DUNGEONSIZE);

	for(int i = 0; i < 9; i++)
	{
		// Build Rooms
		if(i < 3)
		{
			dungeon[i] = createRoom(1, i * CELLWIDTH, intRand(4, CELLWIDTH - CELLSPACER), intRand(4, CELLHEIGHT - CELLSPACER));
		}
		else if(i < 6)
		{
			dungeon[i] = createRoom(CELLHEIGHT, (i - 3) * CELLWIDTH, intRand(4, CELLWIDTH - CELLSPACER), intRand(4, CELLHEIGHT - CELLSPACER));
		}
		else
		{
			dungeon[i] = createRoom((CELLHEIGHT * 2) - 1, (i - 6) * CELLWIDTH, intRand(4, CELLWIDTH - CELLSPACER), intRand(4, CELLHEIGHT - CELLSPACER));
		}

		if(dungeon[i]->position.x + dungeon[i]->width != (i+1) * CELLWIDTH && dungeon[i]->position.x != i * CELLWIDTH)
		{
			dungeon[i]->position.x += intRand(0, (CELLWIDTH - dungeon[i]->width)- (CELLSPACER/2));
		}

		if(dungeon[i]->type != HALLPIVOT)
		{
			//if (dungeon[i]->discovered)
				drawRoom(dungeon[i]);
		}
		else
		{
			dungeon[i]->width = 1;
			dungeon[i]->height = 1;
		}
	}

	return dungeon;
}

Room * createRoom(int y, int x, int width, int height)
{
	Room * newRoom;
	newRoom = malloc(sizeof(Room));

	newRoom->position.x = x;
	newRoom->position.y = y;
	newRoom->width = width;
	newRoom->height = height;
	newRoom->discovered = false;

	int hallRand = intRand(0, 100);

	if(hallRand > 85)
	{
		newRoom->type = HALLPIVOT;
	}
	else
	{
		newRoom->type = DEFAULT;
	}

	return newRoom;
}

int drawRoom(Room * room)
{
	int x;
	int y;

	// draw top and bottom
	for(x = room->position.x; x < room->position.x + room->width; x++)
	{
		mvprintw(room->position.y, x, "-");
		mvprintw(room->position.y + room->height, x, "-");
	}

	// draw floors and walls
	for (y = room->position.y + 1; y < room->position.y + room->height; y++)
	{
		mvprintw(y, room->position.x, "|");
		mvprintw(y, room->position.x + room->width - 1, "|");

		for(x = room->position.x + 1; x < room->position.x +room->width - 1; x++)
		{
			mvprintw(y, x, ".");
		}
	}

	return 0;
}
