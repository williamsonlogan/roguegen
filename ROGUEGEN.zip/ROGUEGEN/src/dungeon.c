#include "dungeon.h"

Room ** buildDungeon()
{
	//TODO: make dungeon size compatable with something other than 9
	Room ** dungeon;
	dungeon = malloc(sizeof(Room*)*DUNGEONSIZE);
	
	for(int i = 0; i < 9; i++)
	{
		// Build Rooms
		// TODO: Randomize size
		if(i < 3)
	 		 dungeon[i] = createRoom(1, i * CELLWIDTH, 6, 6);
	 	else if(i < 6)	 
	 		dungeon[i] = createRoom(CELLHEIGHT, (i - 3) * CELLWIDTH, 6, 6); 
 		else
 			dungeon[i] = createRoom((CELLHEIGHT * 2) - 1, (i - 6) * CELLWIDTH, 6, 6);
 			
		drawRoom(dungeon[i]);
	}
	
	return dungeon;
}

Room * createRoom(int y, int x, int width, int height)
{
	Room * newRoom;
	newRoom = malloc(sizeof(Room));
	
	newRoom->x = x;
	newRoom->y = y;
	newRoom->width = width;
	newRoom->height = height;
	
	return newRoom;
}

int drawRoom(Room * room)
{
	int x;
	int y;
	
	// draw top and bottom
	for(x = room->x; x < room->x + room->width; x++)
	{
		mvprintw(room->y, x, "-");
		mvprintw(room->y + room->height, x, "-");
	}
	
	// draw floors and walls
	for (y = room->y + 1; y < room->y + room->height; y++)
	{
		mvprintw(y, room->x, "|");
		mvprintw(y, room->x + room->width - 1, "|");
		
		for(x = room->x + 1; x < room->x +room->width - 1; x++)
		{
		 	  mvprintw(y, x, ".");
		}
	}
	
	return 0;
}
