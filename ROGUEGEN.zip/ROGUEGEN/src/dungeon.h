#ifndef _DUNGEON_H__
#define _DUNGEON_H__

#include <ncurses.h>
#include <stdlib.h>

#define DUNGEONSIZE 9 //DO NOT EDIT UNTIL buildDungeon is fixed!
// These will eventually be calculated with DUNGEONSIZE
#define CELLWIDTH 27
#define CELLHEIGHT 9

typedef enum ROOMTYPE
{
	ENTRANCE = 0,
	EXIT,
	HALLPIVOT
} ROOMTYPE;

typedef struct Room
{
	int x;
	int y;
	int width;
	int height;
	ROOMTYPE type;
} Room;

Room ** buildDungeon();
Room * createRoom(int y, int x, int width, int height);
int drawRoom(Room * room);

#endif // _DUNGEON_H__
