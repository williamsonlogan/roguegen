#ifndef _DUNGEON_H__
#define _DUNGEON_H__

#include <ncurses.h>
#include <stdlib.h>

#include "utility.h"

#define DUNGEONSIZE 9 //DO NOT EDIT UNTIL buildDungeon is fixed!
// These will eventually be calculated with DUNGEONSIZE
#define CELLWIDTH 27
#define CELLHEIGHT 9
#define CELLSPACER 3

typedef enum ROOMTYPE
{
    ENTRANCE = 0,
    EXIT,
    HALLPIVOT,
    DEFAULT
} ROOMTYPE;

typedef struct Room
{
	Coord position;
	int width;
	int height;
	ROOMTYPE type;
	bool discovered;
} Room;

Room ** buildDungeon();
Room * createRoom(int y, int x, int width, int height);
int drawRoom(Room * room);

#endif // _DUNGEON_H__
